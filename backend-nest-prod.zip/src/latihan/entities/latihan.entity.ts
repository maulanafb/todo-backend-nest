export class Latihan {}
