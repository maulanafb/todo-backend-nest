export class CreateLatihanDto {}
