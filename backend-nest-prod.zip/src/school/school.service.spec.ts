import { Test, TestingModule } from '@nestjs/testing';
import { SchoolService } from './school.service';

describe('SchoolService', () => {
  let service: SchoolService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SchoolService],
    }).compile();

    service = module.get<SchoolService>(SchoolService);
  });

});
