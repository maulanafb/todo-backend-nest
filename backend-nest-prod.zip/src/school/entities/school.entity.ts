export class School {}
