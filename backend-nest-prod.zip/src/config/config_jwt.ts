export const jwt_config = {
  secret: 'awikwok',
  expired: 3600,
};
